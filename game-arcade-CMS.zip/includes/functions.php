<!-- ALL Function Written Here -->
<?php 

// Function to Get Site Title 
function get_site_title(){
    include('./admin/includes/config.php');
    $sql = "SELECT * FROM `tblsettings`";
    $query = mysqli_query($con, $sql);
    if($query){
        while($data = $query->fetch_assoc()){
            echo $data['SiteTitle'];
        }
    }
}

// Function to Get Site Description
function get_site_description(){
    include('./admin/includes/config.php');
    $sql = "SELECT * FROM `tblsettings`";
    $query = mysqli_query($con, $sql);
    if($query){
        while($data = $query->fetch_assoc()){
            echo $data['SiteDescription'];
        }
    }
}

// Function to Get Site Logo
function get_site_logo(){
    include('./admin/includes/config.php');
    $sql = "SELECT * FROM `tblsettings`";
    $query = mysqli_query($con, $sql);
    if($query){
        while($data = $query->fetch_assoc()){
            echo $data['SiteLogo'];
        }
    }
}

// Function to Get Categories List
function get_categories_list(){
    include('./admin/includes/config.php');
    $sql = "SELECT * FROM `tblcategory` WHERE `Is_Active` = 1";
    $query = mysqli_query($con, $sql);
    if($query){
        while($data = $query->fetch_assoc()){ ?>
            <li><a href="categories.php?id=<?php echo $data['id']; ?>"><?php echo $data['CategoryName']; ?></a></li>
        <?php }
    }
}

// Function to Get Advertisement
function get_advertisement($size){
    include('./admin/includes/config.php');
    $sql = "SELECT * FROM `tblads`";
    $query = mysqli_query($con, $sql);
    if($query){
        while($data = $query->fetch_assoc()){
            echo $data[$size];
        }
    }
}

// Function to Get All Games
function get_games(){
    include('./admin/includes/config.php');
    $sql = "select tblgames.GameImage, tblgames.id as postid,tblgames.GameTitle as title,tblcategory.CategoryName as category,tblsubcategory.Subcategory as subcategory from tblgames left join tblcategory on tblcategory.id=tblgames.CategoryId left join tblsubcategory on tblsubcategory.SubCategoryId=tblgames.SubCategoryId where tblgames.Is_Active=1 ";
    $query = mysqli_query($con, $sql);
    if($query){
        while($data = $query->fetch_assoc()){
            include('includes/card.php');
        }
    }
}

// Function to Get Recent Games
function get_recent_games(){
    include('./admin/includes/config.php');
    $sql = "select tblgames.GameImage, tblgames.id as postid,tblgames.GameTitle as title,tblcategory.CategoryName as category,tblsubcategory.Subcategory as subcategory from tblgames left join tblcategory on tblcategory.id=tblgames.CategoryId left join tblsubcategory on tblsubcategory.SubCategoryId=tblgames.SubCategoryId where tblgames.Is_Active=1 LIMIT 5 ";
    $query = mysqli_query($con, $sql);
    if($query){
        while($data = $query->fetch_assoc()){
            include('includes/card.php');
        }
    }
}

// Function to Get Single Games
function get_single_game($id){
    include('./admin/includes/config.php');
    $sql = "SELECT * FROM `tblgames` WHERE `id` = $id";
    $query = mysqli_query($con, $sql);
    if($query){
        while($data = $query->fetch_assoc()){
            echo $data['GameDetails'];
        }
    }
}

// Function to Get Single Games from ID
function get_single_game_id($id){
    include('./admin/includes/config.php');
    $sql = "SELECT * FROM `tblgames` WHERE `id` = $id";
    $query = mysqli_query($con, $sql);
    if($query){
        while($data = $query->fetch_assoc()){
            echo $data['id'];
        }
    }
}

// Function to Get Categories Game
function get_game_categories($id){
    include('./admin/includes/config.php');
    $sql = "SELECT * FROM `tblgames` WHERE `CategoryId` = $id AND `Is_Active` = 1";
    $query = mysqli_query($con, $sql);
    if($query){
        while($data = $query->fetch_assoc()){ ?>
           <div class="col">
            <div class="card" id="big-card-game">
                <img src="./admin/postimages/<?php echo $data['GameImage']; ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><a href="game.php?id=<?php echo $data['id']; ?>"><?php echo $data['GameTitle']; ?></a></h5>
                </div>
            </div>
            </div>
        <?php }
    }
}

// Function to Get Search Query
function get_search($search){
    include('./admin/includes/config.php');
    $sql = "SELECT * FROM `tblgames` WHERE `GameTitle` LIKE '%$search%';`";
    $query = mysqli_query($con, $sql);
    if($query){
        while($data = $query->fetch_assoc()){ ?>
            <div class="col">
            <div class="card" id="big-card-game">
                <img src="./admin/postimages/<?php echo $data['GameImage']; ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><a href="game.php?id=<?php echo $data['id']; ?>"><?php echo $data['GameTitle']; ?></a></h5>
                </div>
            </div>
            </div>
        <?php }
    }
}