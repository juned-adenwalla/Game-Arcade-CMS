<nav>
    <div class="logo">
        <a href="index.php"><img src="./admin/postimages/<?php get_site_logo(); ?>" alt="<?php get_site_title(); ?>"></a>
    </div>
    <div class="search-icon">
        <span class="fas fa-search"></span>
    </div>
    <div class="cancel-icon">
        <span class="fas fa-times"></span>
    </div>
    <form action="search.php" method="GET">
        <input type="search" name="search" class="search-data" placeholder="Search Games" required>
        <button type="submit" class="fas fa-search"></button>
    </form>
</nav>
<div class="container">
    <div class="scroll-bar">
        <?php get_categories_list(); ?>
    </div>
</div>