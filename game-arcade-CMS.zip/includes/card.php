<div class="col">
            <div class="card" id="big-card-game">
                <img src="./admin/postimages/<?php echo $data['GameImage']; ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><a href="game.php?id=<?php echo $data['postid']; ?>"><?php echo $data['title']; ?></a></h5>
                    <div><span class="badge bg-secondary"><?php echo $data['category']; ?></span>&nbsp;<span class="badge bg-secondary"><?php echo $data['subcategory']; ?></span></div>
                </div>
            </div>
            </div>